# Health & Science Africa — Mobile App
### React Native (Expo) · AdMob · Claude AI · APK Ready

---

## 📁 Project Structure

```
health-science-africa/
├── App.js                        # Root navigator
├── app.json                      # Expo config + AdMob plugin
├── eas.json                      # EAS Build profiles (APK / AAB)
├── package.json
├── babel.config.js
├── assets/                       # Icons, splash screen (add your images here)
├── src/
│   ├── config/
│   │   ├── index.js              # AdMob IDs, API keys, colors
│   │   └── articles.js           # Sample article data
│   ├── components/
│   │   ├── AdBanner.js           # BannerAd wrapper
│   │   └── useAds.js             # Interstitial + Rewarded hooks
│   └── screens/
│       ├── HomeScreen.js         # Feed + featured hero
│       ├── AIScreen.js           # HealthBot (Claude-powered)
│       └── OtherScreens.js       # Article, Explore, Bookmarks, Settings
```

---

## 🚀 BUILD YOUR APK — Step by Step

### Step 1 — Prerequisites (one-time setup)
```bash
# Install Node.js 18+ from https://nodejs.org
# Then install Expo CLI and EAS CLI globally:
npm install -g expo-cli eas-cli
```

### Step 2 — Install dependencies
```bash
cd health-science-africa
npm install
```

### Step 3 — Add your API keys
Edit `src/config/index.js`:
```js
export const ANTHROPIC_API_KEY = 'sk-ant-YOUR-KEY-HERE';  // From console.anthropic.com

// Production AdMob IDs (from admob.google.com):
const PROD_IDS = {
  BANNER:       'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX',
  INTERSTITIAL: 'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX',
  REWARDED:     'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX',
  NATIVE:       'ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX',
};
```

Edit `app.json` — replace the AdMob App ID:
```json
"androidAppId": "ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX"
```

### Step 4 — Add assets
Place these files in the `assets/` folder:
- `icon.png` (1024×1024 px)
- `splash.png` (1284×2778 px)
- `adaptive-icon.png` (1024×1024 px)
- `favicon.png` (48×48 px)
- `notification-icon.png` (96×96 px, white on transparent)

### Step 5 — Create EAS account and project
```bash
# Login or create a free account at expo.dev
eas login

# Link this project to EAS
eas init
```
Copy the generated `projectId` into `app.json` → `extra.eas.projectId`.

### Step 6 — Build the APK (free cloud build, no Android Studio needed)
```bash
# Build APK (direct install, for testing / sideloading)
eas build -p android --profile preview

# OR build AAB (for Google Play Store submission)
eas build -p android --profile production
```
EAS will build in the cloud. When done, you get a download link for the APK.

### Step 7 — Install on your Android device
```bash
# Option A: Download the APK link EAS gives you, sideload on phone
# Option B: Use ADB
adb install health-science-africa.apk
```

---

## 📱 Running Locally (without building)
```bash
# Install Expo Go on your phone from Play Store, then:
npx expo start

# Scan the QR code with Expo Go
```

---

## 💰 AdMob Setup Guide

1. Go to https://admob.google.com
2. Create an App → "Health & Science Africa" → Android
3. Create 4 Ad Units: Banner, Interstitial, Rewarded, Native
4. Copy each Ad Unit ID into `src/config/index.js` → `PROD_IDS`
5. Copy the App ID into `app.json` → `plugins → react-native-google-mobile-ads → androidAppId`
6. While testing, leave `__DEV__` = true — this uses Google's official test IDs automatically

### Revenue Streams Implemented
| Type         | Trigger                          | Avg eCPM  |
|--------------|----------------------------------|-----------|
| Banner       | Home feed top, article footer    | $0.5–$2   |
| Native       | Every 4 articles in feed         | $1–$4     |
| Interstitial | Between article opens (hook ready)| $3–$8    |
| Rewarded     | AI extra questions               | $5–$15    |
| Premium IAP  | Remove ads (settings button)     | Custom    |

---

## 🤖 AI (HealthBot) Setup

1. Get an API key from https://console.anthropic.com
2. Add it to `src/config/index.js` → `ANTHROPIC_API_KEY`
3. **For production**: move the API key to a backend proxy (Node.js/Flask)
   so it's never shipped inside the APK.

---

## 🌐 Connect to Live Website API

Replace sample articles with live WordPress API data in `HomeScreen.js`:
```js
useEffect(() => {
  fetch('https://healthandscienceafrica.com/wp-json/wp/v2/posts?per_page=20')
    .then(r => r.json())
    .then(posts => setArticles(posts));
}, []);
```

---

## 📦 Publishing to Google Play Store

```bash
# Build production AAB
eas build -p android --profile production

# Submit to Play Store (requires google-play-service-account.json)
eas submit -p android
```

---

## 🛠 Tech Stack
- **React Native** via Expo SDK 51
- **expo-router** navigation
- **react-native-google-mobile-ads** — AdMob
- **@react-native-async-storage** — bookmarks persistence
- **Claude API** (claude-sonnet-4) — HealthBot AI
- **EAS Build** — cloud APK/AAB compilation

---

*© 2026 Health and Science Ltd. · healthandscienceafrica.com*
