import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, ScrollView,
  StyleSheet, KeyboardAvoidingView, Platform, ActivityIndicator, Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { GEMINI_API_KEY, GEMINI_API_URL, AI_SYSTEM_PROMPT, APP_CONFIG } from '../config';
import AdBanner from '../components/AdBanner';
import { useRewardedAd } from '../components/useAds';

const C = APP_CONFIG.colors;
const FREE_DAILY_LIMIT = 15;
const REWARDED_BONUS = 5;

const SUGGESTIONS = [
  'What is lenacapavir?',
  'TB prevention tips',
  'Diabetes in Africa',
  'HIV PrEP explained',
  'Malaria symptoms',
  'Childhood asthma triggers',
];

export default function AIScreen() {
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: "👋 Hi! I'm HealthBot — your FREE AI health assistant for Africa, powered by Google Gemini. Ask me anything about health, science, or medicine on the continent!",
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [questionsLeft, setQuestionsLeft] = useState(FREE_DAILY_LIMIT);
  const scrollRef = useRef(null);
  const { showAd: showRewarded, loaded: rewardedReady } = useRewardedAd();

  useEffect(() => {
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 100);
  }, [messages, loading]);

  async function sendMessage() {
    const text = input.trim();
    if (!text || loading) return;

    if (questionsLeft <= 0) {
      Alert.alert(
        'Daily Limit Reached',
        'Watch a short ad to earn 5 more questions!',
        [
          { text: 'Watch Ad', onPress: watchAdForQuestions },
          { text: 'Cancel', style: 'cancel' },
        ]
      );
      return;
    }

    const userMsg = { role: 'user', content: text };
    const newHistory = [...messages, userMsg];
    setMessages(newHistory);
    setInput('');
    setLoading(true);
    setQuestionsLeft(q => q - 1);

    try {
      // Build Gemini conversation history
      const geminiContents = newHistory
        .filter((m, i) => !(i === 0 && m.role === 'assistant')) // skip welcome msg
        .map(m => ({
          role: m.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: m.content }],
        }));

      const res = await fetch(`${GEMINI_API_URL}?key=${GEMINI_API_KEY}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system_instruction: {
            parts: [{ text: AI_SYSTEM_PROMPT }],
          },
          contents: geminiContents,
          generationConfig: {
            maxOutputTokens: 512,
            temperature: 0.7,
          },
        }),
      });

      const data = await res.json();
      const reply =
        data?.candidates?.[0]?.content?.parts?.[0]?.text ||
        'Sorry, I could not get a response. Please try again.';

      setMessages(prev => [...prev, { role: 'assistant', content: reply }]);
    } catch (e) {
      setMessages(prev => [
        ...prev,
        { role: 'assistant', content: '⚠️ Network error. Please check your connection and try again.' },
      ]);
    }
    setLoading(false);
  }

  function watchAdForQuestions() {
    if (rewardedReady) {
      showRewarded(() => {
        setQuestionsLeft(q => q + REWARDED_BONUS);
        Alert.alert('🎁 Reward Earned!', `You've unlocked ${REWARDED_BONUS} more questions!`);
      });
    } else {
      // Fallback if ad not loaded yet
      setQuestionsLeft(q => q + REWARDED_BONUS);
      Alert.alert('🎁 Bonus!', `You've earned ${REWARDED_BONUS} more questions!`);
    }
  }

  return (
    <SafeAreaView style={styles.safe}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.botAvatar}>
          <Text style={{ fontSize: 22 }}>🤖</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.botName}>HealthBot AI</Text>
          <Text style={styles.botSub}>Powered by Google Gemini · Free · Africa Focus</Text>
        </View>
        <View style={styles.onlineRow}>
          <View style={styles.statusDot} />
          <Text style={styles.statusText}>Online</Text>
        </View>
      </View>

      {/* Questions counter bar */}
      <View style={styles.counterBar}>
        <Text style={styles.counterText}>
          {questionsLeft > 0
            ? `🔢 ${questionsLeft} free questions left today`
            : '⚠️ Daily limit reached — watch ad for more'}
        </Text>
        <TouchableOpacity onPress={watchAdForQuestions} style={styles.earnBtn}>
          <Text style={styles.earnBtnText}>+{REWARDED_BONUS} Free</Text>
        </TouchableOpacity>
      </View>

      {/* Top ad */}
      <AdBanner size="BANNER" />

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={90}>

        {/* Messages */}
        <ScrollView
          ref={scrollRef}
          style={styles.msgList}
          contentContainerStyle={{ paddingHorizontal: 16, paddingVertical: 10 }}
          showsVerticalScrollIndicator={false}>

          {messages.map((m, i) => (
            <View key={i} style={[styles.msgRow, m.role === 'user' && styles.msgRowUser]}>
              {m.role === 'assistant' && (
                <View style={styles.msgAvatar}>
                  <Text style={{ fontSize: 14 }}>🤖</Text>
                </View>
              )}
              <View style={[
                styles.bubble,
                m.role === 'user' ? styles.bubbleUser : styles.bubbleBot,
              ]}>
                <Text style={[styles.bubbleText, m.role === 'user' && styles.bubbleTextUser]}>
                  {m.content}
                </Text>
              </View>
            </View>
          ))}

          {loading && (
            <View style={styles.msgRow}>
              <View style={styles.msgAvatar}>
                <Text style={{ fontSize: 14 }}>🤖</Text>
              </View>
              <View style={styles.bubbleBot}>
                <ActivityIndicator color={C.primary} size="small" />
              </View>
            </View>
          )}
        </ScrollView>

        {/* Suggestions (shown only at start) */}
        {messages.length <= 2 && (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 16, gap: 8, paddingVertical: 8 }}>
            {SUGGESTIONS.map(s => (
              <TouchableOpacity key={s} onPress={() => setInput(s)} style={styles.suggChip}>
                <Text style={styles.suggText}>{s}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        )}

        {/* Input row */}
        <View style={styles.inputRow}>
          <TextInput
            value={input}
            onChangeText={setInput}
            onSubmitEditing={sendMessage}
            placeholder="Ask a health or science question..."
            placeholderTextColor={C.textMuted}
            style={styles.input}
            multiline
            maxLength={500}
          />
          <TouchableOpacity
            onPress={sendMessage}
            disabled={loading}
            style={[styles.sendBtn, loading && styles.sendBtnDisabled]}>
            <Text style={{ fontSize: 18 }}>➤</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },

  header: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: '#0a2030',
  },
  botAvatar: {
    width: 42, height: 42, borderRadius: 21,
    backgroundColor: C.primary + '33',
    borderWidth: 1, borderColor: C.primary + '55',
    alignItems: 'center', justifyContent: 'center',
  },
  botName:    { color: C.primary, fontWeight: '800', fontSize: 14 },
  botSub:     { color: C.textMuted, fontSize: 10 },
  onlineRow:  { flexDirection: 'row', alignItems: 'center', gap: 5 },
  statusDot:  { width: 8, height: 8, borderRadius: 4, backgroundColor: C.primary },
  statusText: { color: C.primary, fontSize: 11 },

  counterBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 8,
    backgroundColor: '#0a2010', borderBottomWidth: 1, borderBottomColor: '#1a4a2a',
  },
  counterText: { color: '#4a9a6a', fontSize: 11, flex: 1 },
  earnBtn:     { backgroundColor: C.primary, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 6, marginLeft: 8 },
  earnBtnText: { color: '#000', fontWeight: '800', fontSize: 10 },

  msgList: { flex: 1 },
  msgRow:     { flexDirection: 'row', marginBottom: 12, alignItems: 'flex-end', gap: 8 },
  msgRowUser: { flexDirection: 'row-reverse' },
  msgAvatar:  {
    width: 28, height: 28, borderRadius: 14,
    backgroundColor: C.primary + '33',
    alignItems: 'center', justifyContent: 'center', flexShrink: 0,
  },
  bubble:         { maxWidth: '78%', padding: 12, borderRadius: 16 },
  bubbleBot:      { backgroundColor: '#0d2030', borderWidth: 1, borderColor: '#1a3a5a', borderBottomLeftRadius: 4 },
  bubbleUser:     { backgroundColor: C.primary, borderBottomRightRadius: 4 },
  bubbleText:     { color: C.text, fontSize: 13, lineHeight: 20 },
  bubbleTextUser: { color: '#000' },

  suggChip: {
    backgroundColor: '#0d2030', borderWidth: 1, borderColor: '#1a4a6a',
    borderRadius: 16, paddingHorizontal: 12, paddingVertical: 7,
  },
  suggText: { color: C.secondary, fontSize: 11 },

  inputRow: {
    flexDirection: 'row', alignItems: 'flex-end', gap: 8,
    padding: 12, borderTopWidth: 1, borderTopColor: '#0a2030',
  },
  input: {
    flex: 1, backgroundColor: '#0d2030', borderWidth: 1, borderColor: '#1a3a5a',
    borderRadius: 22, paddingHorizontal: 16, paddingVertical: 10,
    color: C.text, fontSize: 13, maxHeight: 100,
  },
  sendBtn:         { width: 46, height: 46, borderRadius: 23, backgroundColor: C.primary, alignItems: 'center', justifyContent: 'center' },
  sendBtnDisabled: { backgroundColor: '#0a3a2a' },
});
