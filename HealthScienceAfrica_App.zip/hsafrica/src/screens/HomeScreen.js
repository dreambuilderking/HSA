import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  Dimensions, Image, ActivityIndicator, RefreshControl,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { CATEGORIES, API_BASE, mapPost } from '../config/articles';
import { APP_CONFIG } from '../config';
import AdBanner from '../components/AdBanner';
import { useInterstitialAd } from '../components/useAds';

const { width } = Dimensions.get('window');
const C = APP_CONFIG.colors;

// ─── Hero Card ────────────────────────────────────────────────────────────────
function HeroCard({ article, onPress }) {
  return (
    <TouchableOpacity onPress={() => onPress(article)} activeOpacity={0.85}
      style={[styles.heroCard, { borderColor: article.color + '55' }]}>
      {article.image ? (
        <Image source={{ uri: article.image }} style={styles.heroImage} resizeMode="cover" />
      ) : (
        <View style={[styles.heroImageFallback, { backgroundColor: article.color + '22' }]}>
          <Text style={{ fontSize: 56, opacity: 0.4 }}>{article.icon}</Text>
        </View>
      )}
      <View style={styles.heroOverlay}>
        <View style={[styles.tagChip, { backgroundColor: article.color }]}>
          <Text style={styles.tagText}>{article.category.toUpperCase()}</Text>
        </View>
        <Text style={styles.heroTitle} numberOfLines={3}>{article.title}</Text>
        <Text style={styles.heroPill}>{article.author} · {article.date}</Text>
      </View>
    </TouchableOpacity>
  );
}

// ─── Article Row ──────────────────────────────────────────────────────────────
function ArticleRow({ article, onPress }) {
  return (
    <TouchableOpacity onPress={() => onPress(article)} style={styles.articleRow} activeOpacity={0.8}>
      {article.image ? (
        <Image source={{ uri: article.image }} style={styles.articleThumb} resizeMode="cover" />
      ) : (
        <View style={[styles.articleThumb, styles.articleThumbFallback, { backgroundColor: article.color + '22' }]}>
          <Text style={{ fontSize: 24 }}>{article.icon}</Text>
        </View>
      )}
      <View style={styles.articleInfo}>
        <Text style={[styles.articleCat, { color: article.color }]}>{article.category.toUpperCase()}</Text>
        <Text style={styles.articleTitle} numberOfLines={2}>{article.title}</Text>
        <Text style={styles.articleMeta}>{article.author} · {article.readTime} read</Text>
      </View>
    </TouchableOpacity>
  );
}

// ─── Home Screen ──────────────────────────────────────────────────────────────
export default function HomeScreen() {
  const navigation = useNavigation();
  const [activeCat, setActiveCat] = useState(CATEGORIES[0]);
  const [articles, setArticles] = useState([]);
  const [featured, setFeatured] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const { showAd } = useInterstitialAd();
  const articleOpenCount = React.useRef(0);

  const fetchArticles = useCallback(async (cat, pageNum = 1, append = false) => {
    try {
      const catParam = cat.id ? `&categories=${cat.id}` : '';
      const url = `${API_BASE}/posts?per_page=15&page=${pageNum}&_embed${catParam}`;
      const res = await fetch(url);
      const total = parseInt(res.headers.get('X-WP-TotalPages') || '1');
      const data = await res.json();
      const mapped = data.map(mapPost);
      if (append) {
        setArticles(prev => [...prev, ...mapped]);
      } else {
        setArticles(mapped);
        // Use first 3 Health articles as featured on All tab
        if (!cat.id) setFeatured(mapped.filter(a => a.catId === 27).slice(0, 3));
        else setFeatured(mapped.slice(0, 2));
      }
      setHasMore(pageNum < total);
    } catch (e) {
      console.error('Fetch error:', e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    setLoading(true);
    setPage(1);
    fetchArticles(activeCat, 1, false);
  }, [activeCat]);

  function openArticle(article) {
    articleOpenCount.current += 1;
    if (articleOpenCount.current % 3 === 0) showAd();
    navigation.navigate('Article', { article });
  }

  function onRefresh() {
    setRefreshing(true);
    setPage(1);
    fetchArticles(activeCat, 1, false);
  }

  function loadMore() {
    if (!hasMore || loading) return;
    const next = page + 1;
    setPage(next);
    fetchArticles(activeCat, next, true);
  }

  return (
    <SafeAreaView style={styles.safe}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>Health & Science</Text>
          <Text style={styles.headerSub}>AFRICA</Text>
        </View>
        <View style={styles.headerRight}>
          <View style={styles.liveDot} />
          <Text style={styles.liveText}>LIVE</Text>
        </View>
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={C.primary} />}
        onScroll={({ nativeEvent }) => {
          const { layoutMeasurement, contentOffset, contentSize } = nativeEvent;
          if (layoutMeasurement.height + contentOffset.y >= contentSize.height - 300) loadMore();
        }}
        scrollEventThrottle={400}>

        {/* Top Banner Ad */}
        <AdBanner size="ADAPTIVE" />

        {/* Hero Carousel */}
        {featured.length > 0 && (
          <ScrollView horizontal showsHorizontalScrollIndicator={false}
            style={styles.heroScroll}
            contentContainerStyle={{ paddingHorizontal: 16, gap: 12 }}>
            {featured.map(a => <HeroCard key={a.id} article={a} onPress={openArticle} />)}
          </ScrollView>
        )}

        {/* Category Chips */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false}
          style={styles.catScroll}
          contentContainerStyle={{ paddingHorizontal: 16, gap: 8 }}>
          {CATEGORIES.map(c => (
            <TouchableOpacity key={c.name} onPress={() => setActiveCat(c)}
              style={[styles.catChip, activeCat.name === c.name && { backgroundColor: c.color || C.primary, borderColor: c.color || C.primary }]}>
              <Text style={{ marginRight: 4 }}>{c.icon}</Text>
              <Text style={[styles.catChipText, activeCat.name === c.name && styles.catChipTextActive]}>
                {c.name}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Feed */}
        {loading ? (
          <View style={styles.loadingBox}>
            <ActivityIndicator color={C.primary} size="large" />
            <Text style={styles.loadingText}>Loading latest news...</Text>
          </View>
        ) : (
          <View style={styles.feedSection}>
            {articles.map((a, i) => (
              <View key={`${a.id}-${i}`}>
                <ArticleRow article={a} onPress={openArticle} />
                {(i + 1) % 5 === 0 && <AdBanner size="BANNER" style={{ marginHorizontal: 16 }} />}
              </View>
            ))}
            {hasMore && (
              <ActivityIndicator color={C.primary} style={{ marginVertical: 20 }} />
            )}
            {!hasMore && articles.length > 0 && (
              <Text style={styles.endText}>You're all caught up ✓</Text>
            )}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: '#0a2030',
  },
  headerTitle: { color: C.primary, fontSize: 17, fontWeight: '800', letterSpacing: -0.3 },
  headerSub:   { color: C.textMuted, fontSize: 9, letterSpacing: 3 },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  liveDot:     { width: 7, height: 7, borderRadius: 4, backgroundColor: '#ff4466' },
  liveText:    { color: '#ff4466', fontSize: 10, fontWeight: '900', letterSpacing: 1 },

  heroScroll: { marginTop: 12 },
  heroCard:   { width: width * 0.78, borderRadius: 16, overflow: 'hidden', borderWidth: 1, backgroundColor: '#0d1b2a' },
  heroImage:  { width: '100%', height: 130 },
  heroImageFallback: { height: 130, alignItems: 'flex-end', justifyContent: 'center', paddingRight: 20 },
  heroOverlay:{ padding: 14 },
  tagChip:    { alignSelf: 'flex-start', borderRadius: 5, paddingHorizontal: 8, paddingVertical: 3, marginBottom: 6 },
  tagText:    { color: '#000', fontSize: 8, fontWeight: '900', letterSpacing: 1.2 },
  heroTitle:  { color: '#e4f4ff', fontSize: 14, fontWeight: '700', lineHeight: 20, marginBottom: 6 },
  heroPill:   { color: C.textMuted, fontSize: 10 },

  catScroll:        { marginTop: 14, marginBottom: 4 },
  catChip:          { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 7, borderRadius: 20, backgroundColor: '#0d2030', borderWidth: 1, borderColor: '#1a3a5a' },
  catChipText:      { color: C.textMuted, fontSize: 11, fontWeight: '700' },
  catChipTextActive:{ color: '#000' },

  feedSection:    { paddingTop: 8, paddingBottom: 20 },
  articleRow:     { flexDirection: 'row', alignItems: 'flex-start', gap: 12, paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#0d1e2e' },
  articleThumb:   { width: 72, height: 72, borderRadius: 12, flexShrink: 0 },
  articleThumbFallback: { alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: '#1a3a5a' },
  articleInfo:    { flex: 1 },
  articleCat:     { fontSize: 9, fontWeight: '800', letterSpacing: 1.5, marginBottom: 3 },
  articleTitle:   { color: '#d4e8f8', fontSize: 13, fontWeight: '700', lineHeight: 19, marginBottom: 5 },
  articleMeta:    { color: C.textMuted, fontSize: 10 },

  loadingBox:   { alignItems: 'center', paddingVertical: 60, gap: 12 },
  loadingText:  { color: C.textMuted, fontSize: 12 },
  endText:      { textAlign: 'center', color: C.textMuted, fontSize: 11, paddingVertical: 20 },
});
