import React, { useState, useCallback } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  Linking, Share, Image, ActivityIndicator, TextInput, Switch,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation, useRoute, useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { APP_CONFIG } from '../config';
import { CATEGORIES, API_BASE, mapPost } from '../config/articles';
import AdBanner from '../components/AdBanner';

const C = APP_CONFIG.colors;

// ─── Article Detail ───────────────────────────────────────────────────────────
export function ArticleScreen() {
  const navigation = useNavigation();
  const { params: { article } } = useRoute();
  const [bookmarked, setBookmarked] = useState(false);

  useFocusEffect(useCallback(() => {
    AsyncStorage.getItem('bookmarks').then(v => {
      const bm = v ? JSON.parse(v) : [];
      setBookmarked(bm.some(a => a.id === article.id));
    });
  }, []));

  async function toggleBookmark() {
    const v = await AsyncStorage.getItem('bookmarks');
    const bm = v ? JSON.parse(v) : [];
    const exists = bm.some(a => a.id === article.id);
    const updated = exists ? bm.filter(a => a.id !== article.id) : [...bm, article];
    await AsyncStorage.setItem('bookmarks', JSON.stringify(updated));
    setBookmarked(!exists);
  }

  return (
    <SafeAreaView style={ss.safe}>
      <View style={ss.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={ss.backBtn}>
          <Text style={ss.backText}>← Back</Text>
        </TouchableOpacity>
        <View style={{ flexDirection: 'row', gap: 16 }}>
          <TouchableOpacity onPress={toggleBookmark}>
            <Text style={{ fontSize: 20, color: bookmarked ? C.primary : C.textMuted }}>🔖</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => Share.share({ message: article.title, url: article.link })}>
            <Text style={ss.shareBtn}>↗</Text>
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 30 }} showsVerticalScrollIndicator={false}>
        {/* Featured Image */}
        {article.image ? (
          <Image source={{ uri: article.image }} style={ss.heroImg} resizeMode="cover" />
        ) : (
          <View style={[ss.heroImgFallback, { backgroundColor: article.color + '22' }]}>
            <Text style={{ fontSize: 64, opacity: 0.3 }}>{article.icon}</Text>
          </View>
        )}

        <View style={{ padding: 16 }}>
          <View style={[ss.chip, { backgroundColor: article.color }]}>
            <Text style={ss.chipTxt}>{article.category.toUpperCase()}</Text>
          </View>
          <Text style={ss.title}>{article.title}</Text>
          <Text style={ss.meta}>By {article.author} · {article.date} · {article.readTime} read</Text>

          <AdBanner size="BANNER" style={{ marginVertical: 14 }} />

          <Text style={ss.excerpt}>{article.excerpt}</Text>

          <TouchableOpacity onPress={() => Linking.openURL(article.link)} style={ss.readBtn}>
            <Text style={ss.readBtnTxt}>Read Full Article on Website →</Text>
          </TouchableOpacity>

          <AdBanner size="MEDIUM_RECTANGLE" style={{ marginTop: 20 }} />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

// ─── Explore ──────────────────────────────────────────────────────────────────
export function ExploreScreen() {
  const navigation = useNavigation();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [searching, setSearching] = useState(false);

  async function doSearch(text) {
    setQuery(text);
    if (text.length < 2) { setResults([]); return; }
    setSearching(true);
    try {
      const res = await fetch(`${API_BASE}/posts?search=${encodeURIComponent(text)}&per_page=20&_embed`);
      const data = await res.json();
      setResults(data.map(mapPost));
    } catch {}
    setSearching(false);
  }

  return (
    <SafeAreaView style={ss.safe}>
      <View style={{ padding: 16 }}>
        <Text style={ss.screenTitle}>Explore</Text>
        <View style={ss.searchBox}>
          <Text style={{ fontSize: 16, marginRight: 8 }}>🔍</Text>
          <TextInput
            value={query} onChangeText={doSearch}
            placeholder="Search articles, topics..." placeholderTextColor={C.textMuted}
            style={ss.searchInput}
          />
          {searching && <ActivityIndicator color={C.primary} size="small" />}
        </View>
      </View>

      <ScrollView contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 20 }}>
        {query.length >= 2 ? (
          results.length > 0
            ? results.map(a => (
                <TouchableOpacity key={a.id} onPress={() => navigation.navigate('Article', { article: a })}
                  style={ss.resultRow}>
                  {a.image
                    ? <Image source={{ uri: a.image }} style={ss.resultThumb} resizeMode="cover" />
                    : <View style={[ss.resultThumb, { backgroundColor: a.color + '22', alignItems: 'center', justifyContent: 'center' }]}><Text style={{ fontSize: 22 }}>{a.icon}</Text></View>
                  }
                  <View style={{ flex: 1 }}>
                    <Text style={[ss.articleCat, { color: a.color }]}>{a.category}</Text>
                    <Text style={ss.resultTitle} numberOfLines={2}>{a.title}</Text>
                    <Text style={{ color: C.textMuted, fontSize: 10 }}>{a.date}</Text>
                  </View>
                </TouchableOpacity>
              ))
            : !searching && <Text style={ss.noResults}>No results for "{query}"</Text>
        ) : (
          <>
            <Text style={ss.sectionLabel}>BROWSE CATEGORIES</Text>
            <View style={ss.catGrid}>
              {CATEGORIES.filter(c => c.id).map(c => (
                <TouchableOpacity key={c.name}
                  style={[ss.catTile, { borderColor: c.color + '44', backgroundColor: c.color + '11' }]}
                  onPress={() => navigation.navigate('Home', { categoryFilter: c })}>
                  <Text style={{ fontSize: 28, marginBottom: 6 }}>{c.icon}</Text>
                  <Text style={{ color: C.text, fontWeight: '700', fontSize: 12 }}>{c.name}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <AdBanner size="BANNER" style={{ marginTop: 16 }} />
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

// ─── Bookmarks ────────────────────────────────────────────────────────────────
export function BookmarksScreen() {
  const navigation = useNavigation();
  const [bookmarks, setBookmarks] = useState([]);

  useFocusEffect(useCallback(() => {
    AsyncStorage.getItem('bookmarks').then(v => v && setBookmarks(JSON.parse(v)));
  }, []));

  function remove(id) {
    const updated = bookmarks.filter(a => a.id !== id);
    setBookmarks(updated);
    AsyncStorage.setItem('bookmarks', JSON.stringify(updated));
  }

  return (
    <SafeAreaView style={ss.safe}>
      <View style={{ padding: 16 }}>
        <Text style={ss.screenTitle}>Saved Articles</Text>
      </View>
      <ScrollView contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 20 }}>
        {bookmarks.length === 0 ? (
          <View style={ss.emptyState}>
            <Text style={{ fontSize: 52 }}>🔖</Text>
            <Text style={ss.emptyTitle}>No saved articles</Text>
            <Text style={ss.emptyBody}>Tap the bookmark icon while reading to save articles here.</Text>
          </View>
        ) : bookmarks.map(a => (
          <View key={a.id} style={{ flexDirection: 'row', alignItems: 'center' }}>
            <TouchableOpacity style={{ flex: 1 }} onPress={() => navigation.navigate('Article', { article: a })}>
              <View style={ss.resultRow}>
                {a.image
                  ? <Image source={{ uri: a.image }} style={ss.resultThumb} resizeMode="cover" />
                  : <View style={[ss.resultThumb, { backgroundColor: a.color + '22', alignItems: 'center', justifyContent: 'center' }]}><Text style={{ fontSize: 22 }}>{a.icon}</Text></View>
                }
                <View style={{ flex: 1 }}>
                  <Text style={[ss.articleCat, { color: a.color }]}>{a.category}</Text>
                  <Text style={ss.resultTitle} numberOfLines={2}>{a.title}</Text>
                  <Text style={{ color: C.textMuted, fontSize: 10 }}>{a.date}</Text>
                </View>
              </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => remove(a.id)} style={{ paddingLeft: 10, paddingVertical: 12 }}>
              <Text style={{ color: C.danger, fontSize: 18 }}>✕</Text>
            </TouchableOpacity>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

// ─── Settings ─────────────────────────────────────────────────────────────────
export function SettingsScreen() {
  const [notifications, setNotifications] = useState(true);
  const [personalizedAds, setPersonalizedAds] = useState(true);

  const Row = ({ icon, label, sub, right }) => (
    <View style={ss.settingRow}>
      <Text style={{ fontSize: 18, marginRight: 12 }}>{icon}</Text>
      <View style={{ flex: 1 }}>
        <Text style={ss.settingLabel}>{label}</Text>
        {sub && <Text style={ss.settingSub}>{sub}</Text>}
      </View>
      {right}
    </View>
  );

  return (
    <SafeAreaView style={ss.safe}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>
        <Text style={ss.screenTitle}>Settings</Text>

        <Text style={ss.sectionLabel}>NOTIFICATIONS</Text>
        <Row icon="🔔" label="Push Notifications" sub="Breaking health & science news"
          right={<Switch value={notifications} onValueChange={setNotifications} trackColor={{ true: C.primary }} thumbColor="#fff" />} />

        <Text style={ss.sectionLabel}>MONETIZATION & ADS</Text>
        <Row icon="📢" label="Personalized Ads" sub="More relevant ads for you"
          right={<Switch value={personalizedAds} onValueChange={setPersonalizedAds} trackColor={{ true: C.primary }} thumbColor="#fff" />} />
        <Row icon="💎" label="Remove Ads (Premium)" sub="Ad-free reading experience"
          right={
            <TouchableOpacity style={ss.upgradeBtn}>
              <Text style={ss.upgradeTxt}>Upgrade</Text>
            </TouchableOpacity>
          } />

        <Text style={ss.sectionLabel}>ABOUT</Text>
        <Row icon="🌍" label="Health & Science Africa" sub="healthandscienceafrica.com" />
        <Row icon="📧" label="Contact" sub="info@healthandscienceafrica.com" />
        <Row icon="🔒" label="Privacy Policy"
          right={<TouchableOpacity onPress={() => Linking.openURL(APP_CONFIG.website + '/privacy-policy')}><Text style={{ color: C.primary, fontSize: 12 }}>View →</Text></TouchableOpacity>} />
        <Row icon="🐦" label="Follow on X / Twitter"
          right={<TouchableOpacity onPress={() => Linking.openURL('https://x.com/hsanews1')}><Text style={{ color: C.secondary, fontSize: 12 }}>@hsanews1 →</Text></TouchableOpacity>} />

        <Text style={[ss.footer, { marginTop: 30 }]}>
          Health & Science Africa v1.0.0{'\n'}© 2026 Health & Science Africa Media Ltd.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

// ─── Shared Styles ────────────────────────────────────────────────────────────
const ss = StyleSheet.create({
  safe:        { flex: 1, backgroundColor: C.bg },
  header:      { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, borderBottomWidth: 1, borderBottomColor: '#0a2030' },
  backBtn:     { paddingVertical: 4 },
  backText:    { color: C.primary, fontSize: 14, fontWeight: '700' },
  shareBtn:    { color: C.secondary, fontSize: 20, fontWeight: '700' },
  heroImg:     { width: '100%', height: 220 },
  heroImgFallback: { height: 180, alignItems: 'center', justifyContent: 'center' },
  chip:        { alignSelf: 'flex-start', borderRadius: 5, paddingHorizontal: 8, paddingVertical: 3, marginBottom: 10, marginTop: 14 },
  chipTxt:     { color: '#000', fontSize: 8, fontWeight: '900', letterSpacing: 1.2 },
  title:       { color: '#e4f4ff', fontSize: 19, fontWeight: '800', lineHeight: 27, marginBottom: 8 },
  meta:        { color: C.textMuted, fontSize: 11, marginBottom: 4 },
  excerpt:     { color: '#9ab8d0', fontSize: 14, lineHeight: 24, marginBottom: 20 },
  readBtn:     { backgroundColor: C.primary, borderRadius: 14, padding: 16, alignItems: 'center' },
  readBtnTxt:  { color: '#000', fontWeight: '800', fontSize: 14 },

  screenTitle: { color: '#e4f4ff', fontSize: 20, fontWeight: '800', marginBottom: 14 },
  searchBox:   { flexDirection: 'row', alignItems: 'center', backgroundColor: '#0d2030', borderWidth: 1, borderColor: '#1a3a5a', borderRadius: 24, paddingHorizontal: 16, paddingVertical: 10 },
  searchInput: { flex: 1, color: C.text, fontSize: 13 },
  sectionLabel:{ color: C.textMuted, fontSize: 10, fontWeight: '800', letterSpacing: 2, textTransform: 'uppercase', marginTop: 20, marginBottom: 8 },
  catGrid:     { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  catTile:     { width: '47%', borderRadius: 14, padding: 16, borderWidth: 1 },
  resultRow:   { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#0d1e2e', flex: 1 },
  resultThumb: { width: 64, height: 64, borderRadius: 10, flexShrink: 0 },
  resultTitle: { color: C.text, fontSize: 13, fontWeight: '700', lineHeight: 19, marginTop: 2 },
  articleCat:  { fontSize: 9, fontWeight: '800', letterSpacing: 1.5, textTransform: 'uppercase', marginBottom: 2 },
  noResults:   { color: C.textMuted, textAlign: 'center', padding: 40, fontSize: 13 },
  emptyState:  { alignItems: 'center', paddingVertical: 60 },
  emptyTitle:  { color: C.text, fontSize: 16, fontWeight: '700', marginTop: 12 },
  emptyBody:   { color: C.textMuted, fontSize: 12, textAlign: 'center', marginTop: 6, lineHeight: 18 },
  settingRow:  { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: '#0d1e2e' },
  settingLabel:{ color: C.text, fontSize: 13, fontWeight: '600' },
  settingSub:  { color: C.textMuted, fontSize: 11, marginTop: 2 },
  upgradeBtn:  { backgroundColor: '#f5a62322', borderRadius: 8, paddingHorizontal: 12, paddingVertical: 5, borderWidth: 1, borderColor: '#f5a623' },
  upgradeTxt:  { color: '#f5a623', fontWeight: '800', fontSize: 11 },
  footer:      { textAlign: 'center', color: '#2a4a6a', fontSize: 11, lineHeight: 18 },
});
