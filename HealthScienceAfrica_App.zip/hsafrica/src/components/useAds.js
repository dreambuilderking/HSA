import { useEffect, useState, useCallback } from 'react';
import {
  InterstitialAd,
  RewardedAd,
  AdEventType,
  RewardedAdEventType,
} from 'react-native-google-mobile-ads';
import { AD_IDS } from '../config';

// ─── Interstitial Ad Hook ─────────────────────────────────────────────────────
/**
 * useInterstitialAd
 * Preloads an interstitial and exposes showAd().
 * Call showAd() on article open, screen transitions etc.
 *
 * Usage:
 *   const { showAd } = useInterstitialAd();
 *   <Button onPress={showAd} />
 */
export function useInterstitialAd() {
  const [ad] = useState(() => InterstitialAd.createForAdRequest(AD_IDS.INTERSTITIAL));
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const onLoad  = ad.addAdEventListener(AdEventType.LOADED, () => setLoaded(true));
    const onClose = ad.addAdEventListener(AdEventType.CLOSED, () => {
      setLoaded(false);
      ad.load(); // Preload next
    });
    ad.load();
    return () => { onLoad(); onClose(); };
  }, [ad]);

  const showAd = useCallback(() => {
    if (loaded) ad.show();
  }, [ad, loaded]);

  return { showAd, loaded };
}

// ─── Rewarded Ad Hook ─────────────────────────────────────────────────────────
/**
 * useRewardedAd
 * Preloads a rewarded ad. Call showAd(onRewarded) and receive
 * the reward callback when the user earns the reward.
 *
 * Usage:
 *   const { showAd, loaded } = useRewardedAd();
 *   showAd(() => grantUserExtraQuestions());
 */
export function useRewardedAd() {
  const [ad] = useState(() => RewardedAd.createForAdRequest(AD_IDS.REWARDED));
  const [loaded, setLoaded] = useState(false);
  const [onRewardedRef, setOnRewardedRef] = useState(null);

  useEffect(() => {
    const onLoad    = ad.addAdEventListener(RewardedAdEventType.LOADED, () => setLoaded(true));
    const onEarned  = ad.addAdEventListener(RewardedAdEventType.EARNED_REWARD, (reward) => {
      if (onRewardedRef) onRewardedRef(reward);
    });
    const onClose   = ad.addAdEventListener(AdEventType.CLOSED, () => {
      setLoaded(false);
      ad.load();
    });
    ad.load();
    return () => { onLoad(); onEarned(); onClose(); };
  }, [ad]);

  const showAd = useCallback((onRewarded) => {
    if (loaded) {
      setOnRewardedRef(() => onRewarded);
      ad.show();
    }
  }, [ad, loaded]);

  return { showAd, loaded };
}
