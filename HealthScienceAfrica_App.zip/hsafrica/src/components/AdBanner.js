import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { BannerAd, BannerAdSize, TestIds } from 'react-native-google-mobile-ads';
import { AD_IDS } from '../config';

/**
 * AdBannerComponent
 * Wraps react-native-google-mobile-ads BannerAd.
 * Falls back to a placeholder view if ads fail to load.
 *
 * Usage:
 *   <AdBanner size="BANNER" />
 *   <AdBanner size="MEDIUM_RECTANGLE" />
 *   <AdBanner size="FULL_BANNER" />
 */
export default function AdBanner({ size = 'BANNER', style }) {
  const [failed, setFailed] = useState(false);

  const sizeMap = {
    BANNER:             BannerAdSize.BANNER,
    FULL_BANNER:        BannerAdSize.FULL_BANNER,
    MEDIUM_RECTANGLE:   BannerAdSize.MEDIUM_RECTANGLE,
    LARGE_BANNER:       BannerAdSize.LARGE_BANNER,
    LEADERBOARD:        BannerAdSize.LEADERBOARD,
    ADAPTIVE:           BannerAdSize.ANCHORED_ADAPTIVE_BANNER,
  };

  if (failed) return null;

  return (
    <View style={[styles.container, style]}>
      <Text style={styles.label}>Advertisement</Text>
      <BannerAd
        unitId={AD_IDS.BANNER}
        size={sizeMap[size] || BannerAdSize.BANNER}
        requestOptions={{ requestNonPersonalizedAdsOnly: false }}
        onAdFailedToLoad={() => setFailed(true)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    marginVertical: 8,
    backgroundColor: '#0a1520',
    borderRadius: 8,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#1a2a3a',
  },
  label: {
    fontSize: 9,
    color: '#3a5a7a',
    letterSpacing: 2,
    textTransform: 'uppercase',
    paddingVertical: 4,
  },
});
