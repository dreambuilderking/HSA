import { Platform } from 'react-native';

export const IS_ANDROID = Platform.OS === 'android';

// ─── Test Ad IDs (used automatically during development) ─────────────────────
const TEST_IDS = {
  BANNER:        'ca-app-pub-3940256099942544/6300978111',
  INTERSTITIAL:  'ca-app-pub-3940256099942544/1033173712',
  REWARDED:      'ca-app-pub-3940256099942544/5224354917',
  NATIVE:        'ca-app-pub-3940256099942544/2247696110',
};

// ─── Your Real AdMob IDs ──────────────────────────────────────────────────────
const PROD_IDS = {
  BANNER:        'ca-app-pub-3142443089850225/9718936908',
  INTERSTITIAL:  'ca-app-pub-3142443089850225/8463215463',
  REWARDED:      'ca-app-pub-3142443089850225/8968584716',
  NATIVE:        'ca-app-pub-3142443089850225/7092773564',
};

export const AD_IDS = __DEV__ ? TEST_IDS : PROD_IDS;

// ─── Google Gemini AI ─────────────────────────────────────────────────────────
export const GEMINI_API_KEY = 'AIzaSyBa8d7BWNIDOKp8Wzy-rVjflglOrqx0UQ8';
export const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent';

export const AI_SYSTEM_PROMPT = `You are HealthBot, the intelligent health assistant for Health & Science Africa (healthandscienceafrica.com).
You provide verified, accurate health and science information relevant to the African continent.
Focus on: public health, medical breakthroughs, disease prevention, African healthcare systems, nutrition, mental health, and science research.
Keep answers concise (2-4 sentences for simple questions, up to 6 for complex ones).
Always recommend consulting a qualified healthcare professional for personal medical advice.
Be warm, professional, and culturally sensitive. You are Africa-focused.`;

// ─── App Config ───────────────────────────────────────────────────────────────
export const APP_CONFIG = {
  name: 'Health & Science Africa',
  website: 'https://healthandscienceafrica.com',
  apiBase: 'https://healthandscienceafrica.com/wp-json/wp/v2',
  email: 'info@healthandscienceafrica.com',
  colors: {
    primary: '#00c896',
    secondary: '#0099ff',
    bg: '#060e18',
    card: '#0d1b2a',
    cardBorder: '#1a2a3a',
    text: '#c4e0f8',
    textMuted: '#5a7a9a',
    danger: '#ff4466',
    warning: '#f5a623',
  },
};
