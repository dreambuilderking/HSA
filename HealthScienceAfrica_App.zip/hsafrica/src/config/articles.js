// Real category IDs from healthandscienceafrica.com WordPress API
export const CATEGORIES = [
  { id: null,  name: 'All',             icon: '📰', color: '#00c896' },
  { id: 27,    name: 'Health',          icon: '🏥', color: '#00c896' },
  { id: 29,    name: 'Features',        icon: '⭐', color: '#0099ff' },
  { id: 34,    name: 'Africa',          icon: '🌍', color: '#f5a623' },
  { id: 42,    name: 'Investigation',   icon: '🔎', color: '#ff4466' },
  { id: 44,    name: 'Agriculture',     icon: '🌾', color: '#2ecc71' },
  { id: 47,    name: 'Climate Change',  icon: '🌡️', color: '#3498db' },
  { id: 48,    name: 'HSA TV',          icon: '📺', color: '#9b59b6' },
  { id: 69,    name: 'Branded',         icon: '💼', color: '#1abc9c' },
];

export const CATEGORY_COLOR_MAP = {
  27: '#00c896',
  29: '#0099ff',
  34: '#f5a623',
  42: '#ff4466',
  44: '#2ecc71',
  47: '#3498db',
  48: '#9b59b6',
  69: '#1abc9c',
};

export const CATEGORY_ICON_MAP = {
  27: '🏥',
  29: '⭐',
  34: '🌍',
  42: '🔎',
  44: '🌾',
  47: '🌡️',
  48: '📺',
  69: '💼',
};

export const API_BASE = 'https://healthandscienceafrica.com/wp-json/wp/v2';

// Strip HTML tags from WordPress excerpt/content
export function stripHtml(html = '') {
  return html.replace(/<[^>]*>/g, '').replace(/&amp;/g, '&').replace(/&nbsp;/g, ' ').replace(/&#\d+;/g, '').trim();
}

// Map a raw WP post to a clean article object
export function mapPost(post) {
  const catId = post.categories?.[0];
  return {
    id:       post.id,
    title:    stripHtml(post.title?.rendered || ''),
    excerpt:  stripHtml(post.excerpt?.rendered || ''),
    date:     new Date(post.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }),
    author:   post._embedded?.author?.[0]?.name || 'HSA Reporter',
    image:    post._embedded?.['wp:featuredmedia']?.[0]?.source_url || null,
    link:     post.link,
    category: CATEGORIES.find(c => c.id === catId)?.name || 'News',
    catId,
    color:    CATEGORY_COLOR_MAP[catId] || '#00c896',
    icon:     CATEGORY_ICON_MAP[catId]  || '📰',
    readTime: `${Math.max(1, Math.round((post.content?.rendered?.length || 500) / 1000))} min`,
  };
}
