import React, { useEffect } from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import mobileAds from 'react-native-google-mobile-ads';
import { Text } from 'react-native';

import HomeScreen from './src/screens/HomeScreen';
import AIScreen from './src/screens/AIScreen';
import {
  ArticleScreen,
  ExploreScreen,
  BookmarksScreen,
  SettingsScreen,
} from './src/screens/OtherScreens';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

function HomeTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: '#080f1a',
          borderTopColor: '#0a2030',
          borderTopWidth: 1,
          paddingBottom: 8,
          height: 62,
        },
        tabBarActiveTintColor: '#00c896',
        tabBarInactiveTintColor: '#3a6a8a',
        tabBarLabelStyle: { fontSize: 9, fontWeight: '700', letterSpacing: 0.5 },
      }}>
      <Tab.Screen name="Home" component={HomeScreen}
        options={{ tabBarIcon: ({ color }) => <Text style={{ fontSize: 18, color }}>🏠</Text> }} />
      <Tab.Screen name="Explore" component={ExploreScreen}
        options={{ tabBarIcon: ({ color }) => <Text style={{ fontSize: 18, color }}>🔍</Text> }} />
      <Tab.Screen name="HealthBot" component={AIScreen}
        options={{ tabBarIcon: ({ color }) => <Text style={{ fontSize: 18, color }}>🤖</Text> }} />
      <Tab.Screen name="Saved" component={BookmarksScreen}
        options={{ tabBarIcon: ({ color }) => <Text style={{ fontSize: 18, color }}>🔖</Text> }} />
      <Tab.Screen name="Settings" component={SettingsScreen}
        options={{ tabBarIcon: ({ color }) => <Text style={{ fontSize: 18, color }}>⚙️</Text> }} />
    </Tab.Navigator>
  );
}

export default function App() {
  useEffect(() => {
    mobileAds().initialize().then(() => {
      console.log('AdMob initialized');
    });
  }, []);

  return (
    <SafeAreaProvider>
      <StatusBar style="light" backgroundColor="#060e18" />
      <NavigationContainer>
        <Stack.Navigator screenOptions={{ headerShown: false }}>
          <Stack.Screen name="Main" component={HomeTabs} />
          <Stack.Screen name="Article" component={ArticleScreen}
            options={{ animation: 'slide_from_right' }} />
        </Stack.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}
